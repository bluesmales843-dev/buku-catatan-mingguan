# Catatan Minan – versi 1.2

Pembaruan: nomor plat kendaraan kini diatur per minggu dan ditampilkan tepat di bawah judul CATATAN MINAN pada aplikasi serta gambar yang dibagikan ke WhatsApp. Tekan tombol “Isi nomor plat minggu ini” atau “Ubah nomor plat minggu ini”. Nomor plat disimpan berdasarkan minggu yang dipilih, sehingga dapat berbeda setiap minggu.

Kolom tabel transaksi: Tanggal, Dari, Ke, UJ, Borongan, Sisa. Catatan transaksi lama tetap menggunakan database yang sama.

## Build APK
Unggah isi proyek ini ke repository GitHub yang sudah digunakan, jalankan workflow Build Android APK di tab Actions, lalu unduh artifact BukuCatatanMingguan-APK.
