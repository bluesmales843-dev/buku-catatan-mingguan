# Buku Catatan Mingguan — Android

Proyek Android native untuk buku transaksi mingguan.

## Fitur
- Kolom Tanggal, Dari, Ke, UJ, Borongan, Sisa.
- Tampilan Senin–Minggu dan navigasi minggu sebelumnya/berikutnya.
- Banyak transaksi per tanggal.
- Tambah, edit, dan hapus transaksi.
- Total UJ, Borongan, dan Sisa otomatis.
- Data tersimpan lokal di SQLite.
- Ekspor/berbagi rekap CSV.

## Membuat APK hanya dengan HP Android (melalui GitHub Actions)
Proyek ini sudah menyertakan workflow untuk membangun APK di server GitHub. Anda tidak perlu memasang Android Studio di HP.

1. Unduh dan ekstrak ZIP proyek ini.
2. Buka https://github.com lewat Chrome, masuk atau buat akun.
3. Buat repository baru, misalnya `buku-catatan-mingguan`.
4. Upload seluruh isi folder proyek hasil ekstrak ke repository (pastikan folder `.github/workflows/build-apk.yml` ikut terunggah). Jika unggah lewat browser HP sulit, aktifkan tampilan Situs desktop.
5. Buka tab **Actions** pada repository.
6. Pilih workflow **Build Android APK**, lalu tekan **Run workflow**. Jika workflow belum muncul, pastikan file `.github/workflows/build-apk.yml` sudah masuk ke branch `main`.
7. Tunggu proses build selesai dengan tanda centang hijau.
8. Buka hasil run, cari bagian **Artifacts**, lalu unduh `BukuCatatanMingguan-APK`.
9. Ekstrak ZIP artifact dan buka `app-debug.apk` untuk memasang. Android mungkin meminta izin “Install unknown apps” untuk browser atau aplikasi Files yang digunakan.

APK yang dibuat adalah debug APK untuk instalasi pribadi dan uji coba. Simpan APK dan source project sebagai cadangan.

## Build lokal
Buka proyek dengan Android Studio pada komputer, lalu jalankan `gradle :app:assembleDebug` menggunakan Gradle 8.11.1 dan JDK 17.
