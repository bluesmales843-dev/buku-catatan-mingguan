package com.kingfatih.bukumingguan

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Entry(
    val id: Long,
    val date: String,
    val from: String,
    val to: String,
    val uj: Long,
    val borongan: Long,
    val sisa: Long
)

class LedgerDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "ledger.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            from_name TEXT NOT NULL,
            to_name TEXT NOT NULL,
            uj INTEGER NOT NULL DEFAULT 0,
            borongan INTEGER NOT NULL DEFAULT 0,
            sisa INTEGER NOT NULL DEFAULT 0
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun allBetween(start: String, end: String): List<Entry> {
        val result = mutableListOf<Entry>()
        readableDatabase.rawQuery(
            "SELECT id,date,from_name,to_name,uj,borongan,sisa FROM entries WHERE date BETWEEN ? AND ? ORDER BY date,id",
            arrayOf(start, end)
        ).use { c ->
            while (c.moveToNext()) result.add(
                Entry(c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                    c.getLong(4), c.getLong(5), c.getLong(6))
            )
        }
        return result
    }

    fun save(e: Entry) {
        val values = ContentValues().apply {
            put("date", e.date); put("from_name", e.from); put("to_name", e.to)
            put("uj", e.uj); put("borongan", e.borongan); put("sisa", e.sisa)
        }
        if (e.id == 0L) writableDatabase.insert("entries", null, values)
        else writableDatabase.update("entries", values, "id=?", arrayOf(e.id.toString()))
    }
    fun delete(id: Long) { writableDatabase.delete("entries", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private var weekOffset = 0
    private val navy = Color.rgb(23, 45, 80)
    private val gold = Color.rgb(214, 168, 79)
    private val ink = Color.rgb(35, 45, 60)
    private val muted = Color.rgb(105, 115, 130)
    private val money = NumberFormat.getNumberInstance(Locale("id", "ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LedgerDb(this)
        render()
    }

    private fun weekBounds(offset: Int = weekOffset): Pair<String, String> {
        val c = Calendar.getInstance()
        c.firstDayOfWeek = Calendar.MONDAY
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        c.add(Calendar.WEEK_OF_YEAR, offset)
        val start = c.time
        c.add(Calendar.DAY_OF_MONTH, 6)
        return Pair(fmtDate(start), fmtDate(c.time))
    }

    private fun fmtDate(d: Date) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)
    private fun parseDate(s: String): Date = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s) ?: Date()
    private fun displayDate(s: String): String =
        SimpleDateFormat("dd/MM", Locale("id", "ID")).format(parseDate(s))
    private fun dayName(s: String): String =
        SimpleDateFormat("EEEE", Locale("id", "ID")).format(parseDate(s))
            .replaceFirstChar { it.uppercase() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; setOnClickListener { action() }
        }

    private fun render() {
        val (start, end) = weekBounds()
        val entries = db.allBetween(start, end)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 248, 251))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(navy)
        }
        header.addView(text("BUKU CATATAN", 18f, Color.WHITE, true))
        header.addView(text("MINGGUAN", 27f, gold, true))
        header.addView(text("${displayDate(start)} – ${displayDate(end)}", 13f, Color.WHITE))
        root.addView(header)

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        nav.addView(button("‹ Minggu lalu") { weekOffset--; render() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(button("Minggu depan ›") { weekOffset++; render() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(nav)

        val totalUj = entries.sumOf { it.uj }
        val totalBorongan = entries.sumOf { it.borongan }
        val totalSisa = entries.sumOf { it.sisa }
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(5), 0, dp(10))
        }
        listOf("TOTAL UJ" to totalUj, "BORONGAN" to totalBorongan, "SISA" to totalSisa).forEach { pair ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(9), dp(9), dp(5), dp(9))
                setBackgroundColor(Color.WHITE)
            }
            card.addView(text(pair.first, 10f, muted, true))
            card.addView(text(money.format(pair.second), 17f, navy, true))
            summary.addView(card, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        root.addView(summary)

        root.addView(button("+ Tambah transaksi") { showEntryDialog(null) })

        val horizontal = HorizontalScrollView(this)
        val table = TableLayout(this).apply {
            isStretchAllColumns = false
            setBackgroundColor(Color.WHITE)
        }
        val headerRow = TableRow(this).apply { setBackgroundColor(navy) }
        listOf("TANGGAL", "DARI", "KE", "UJ", "BORONGAN", "SISA", "AKSI").forEach {
            headerRow.addView(cell(it, true))
        }
        table.addView(headerRow)

        val days = (0..6).map { i ->
            val c = Calendar.getInstance()
            c.time = parseDate(start)
            c.add(Calendar.DAY_OF_MONTH, i)
            fmtDate(c.time)
        }
        days.forEach { day ->
            val dayEntries = entries.filter { it.date == day }
            if (dayEntries.isEmpty()) {
                val row = TableRow(this)
                row.addView(cell("${dayName(day)}\n${displayDate(day)}"))
                repeat(6) { row.addView(cell(if (it == 5) "" else "—")) }
                table.addView(row)
            } else {
                dayEntries.forEachIndexed { index, e ->
                    val row = TableRow(this)
                    row.addView(cell("${if (index == 0) dayName(day) else ""}\n${displayDate(day)}"))
                    row.addView(cell(e.from))
                    row.addView(cell(e.to))
                    row.addView(cell(money.format(e.uj)))
                    row.addView(cell(money.format(e.borongan)))
                    row.addView(cell(money.format(e.sisa)))
                    val actions = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        addView(smallAction("Edit") { showEntryDialog(e) })
                        addView(smallAction("Hapus") {
                            AlertDialog.Builder(this@MainActivity)
                                .setMessage("Hapus transaksi ini?")
                                .setNegativeButton("Batal", null)
                                .setPositiveButton("Hapus") { _, _ -> db.delete(e.id); render() }
                                .show()
                        })
                    }
                    row.addView(actions)
                    table.addView(row)
                }
            }
        }
        val totalRow = TableRow(this).apply { setBackgroundColor(navy) }
        totalRow.addView(cell("TOTAL", true))
        totalRow.addView(cell(""))
        totalRow.addView(cell(""))
        totalRow.addView(cell(money.format(totalUj), true))
        totalRow.addView(cell(money.format(totalBorongan), true))
        totalRow.addView(cell(money.format(totalSisa), true))
        totalRow.addView(cell(""))
        table.addView(totalRow)
        horizontal.addView(table)
        val scroll = ScrollView(this)
        scroll.addView(horizontal)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        root.addView(text("Jumlah transaksi: ${entries.size}", 12f, muted))
        root.addView(button("Bagikan catatan ke WhatsApp") { shareWhatsApp(entries, start, end) })
        root.addView(button("Bagikan rekap (CSV)") { shareCsv(entries, start, end) })
        setContentView(root)
    }

    private fun cell(value: String, bold: Boolean = false): TextView =
        text(value, 11f, if (bold) Color.WHITE else ink, bold).apply {
            minWidth = dp(65)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(10), dp(7), dp(10))
            if (!bold) setBackgroundColor(Color.WHITE)
        }

    private fun smallAction(label: String, action: () -> Unit) =
        TextView(this).apply {
            text = label; textSize = 11f; setTextColor(navy)
            setPadding(dp(7), dp(5), dp(7), dp(5))
            setOnClickListener { action() }
        }

    private fun showEntryDialog(existing: Entry?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun field(hint: String, value: String = "", numeric: Boolean = false): EditText {
            val edit = EditText(this)
            edit.hint = hint
            edit.setSingleLine(true)
            if (numeric) edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            edit.setText(value)
            box.addView(edit)
            return edit
        }
        val dateButton = Button(this).apply {
            isAllCaps = false
            text = "Tanggal: ${existing?.date ?: weekBounds().first}"
        }
        var selectedDate = existing?.date ?: weekBounds().first
        dateButton.setOnClickListener {
            val c = Calendar.getInstance()
            c.time = parseDate(selectedDate)
            DatePickerDialog(this, { _, y, m, d ->
                c.set(y, m, d); selectedDate = fmtDate(c.time)
                dateButton.text = "Tanggal: $selectedDate"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        box.addView(dateButton)
        val from = field("Dari", existing?.from ?: "")
        val to = field("Ke", existing?.to ?: "")
        val uj = field("UJ", existing?.uj?.toString() ?: "", true)
        val borongan = field("Borongan", existing?.borongan?.toString() ?: "", true)
        val sisa = field("Sisa", existing?.sisa?.toString() ?: "", true)

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah transaksi" else "Edit transaksi")
            .setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                fun num(v: String) = v.trim().toLongOrNull() ?: 0L
                db.save(Entry(existing?.id ?: 0L, selectedDate,
                    from.text.toString().trim(), to.text.toString().trim(),
                    num(uj.text.toString()), num(borongan.text.toString()), num(sisa.text.toString())))
                render()
            }.show()
    }

    private fun shareWhatsApp(entries: List<Entry>, start: String, end: String) {
        val totalUj = entries.sumOf { it.uj }
        val totalBorongan = entries.sumOf { it.borongan }
        val totalSisa = entries.sumOf { it.sisa }
        val message = buildString {
            append("BUKU CATATAN MINGGUAN\\n")
            append("${displayDate(start)} – ${displayDate(end)}\\n\\n")
            if (entries.isEmpty()) {
                append("Belum ada transaksi.\\n")
            } else {
                entries.forEach { e ->
                    append("${dayName(e.date)}, ${displayDate(e.date)}\\n")
                    append("Dari: ${e.from.ifBlank { "-" }}\\n")
                    append("Ke: ${e.to.ifBlank { "-" }}\\n")
                    append("UJ: ${money.format(e.uj)}\\n")
                    append("Borongan: ${money.format(e.borongan)}\\n")
                    append("Sisa: ${money.format(e.sisa)}\\n\\n")
                }
            }
            append("REKAP MINGGUAN\\n")
            append("Total UJ: ${money.format(totalUj)}\\n")
            append("Total Borongan: ${money.format(totalBorongan)}\\n")
            append("Total Sisa: ${money.format(totalSisa)}\\n")
            append("Jumlah transaksi: ${entries.size}")
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, message)
        }
        startActivity(android.content.Intent.createChooser(intent, "Bagikan catatan"))
    }

    private fun shareCsv(entries: List<Entry>, start: String, end: String) {
        val csv = buildString {
            append("Tanggal,Dari,Ke,UJ,Borongan,Sisa\n")
            entries.forEach {
                append("${it.date},\"${it.from.replace("\"", "\"\"")}\",\"${it.to.replace("\"", "\"\"")}\",${it.uj},${it.borongan},${it.sisa}\n")
            }
            append("TOTAL,,,${entries.sumOf { it.uj }},${entries.sumOf { it.borongan }},${entries.sumOf { it.sisa}}\n")
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Rekap $start sampai $end")
            putExtra(android.content.Intent.EXTRA_TEXT, csv)
        }
        startActivity(android.content.Intent.createChooser(intent, "Bagikan rekap"))
    }
}
