package com.kingfatih.bukumingguan

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Entry(
    val id: Long,
    val date: String,
    val from: String,
    val to: String,
    val plate: String,
    val uj: Long,
    val borongan: Long,
    val sisa: Long
)

class LedgerDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "ledger.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            from_name TEXT NOT NULL,
            to_name TEXT NOT NULL,
            plate TEXT NOT NULL DEFAULT '',
            uj INTEGER NOT NULL DEFAULT 0,
            borongan INTEGER NOT NULL DEFAULT 0,
            sisa INTEGER NOT NULL DEFAULT 0
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE entries ADD COLUMN plate TEXT NOT NULL DEFAULT ''")
    }

    fun allBetween(start: String, end: String): List<Entry> {
        val result = mutableListOf<Entry>()
        readableDatabase.rawQuery(
            "SELECT id,date,from_name,to_name,plate,uj,borongan,sisa FROM entries WHERE date BETWEEN ? AND ? ORDER BY date,id",
            arrayOf(start, end)
        ).use { c ->
            while (c.moveToNext()) result.add(
                Entry(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4),
                    c.getLong(5), c.getLong(6), c.getLong(7))
            )
        }
        return result
    }

    fun save(e: Entry) {
        val values = ContentValues().apply {
            put("date", e.date); put("from_name", e.from); put("to_name", e.to); put("plate", e.plate)
            put("uj", e.uj); put("borongan", e.borongan); put("sisa", e.sisa)
        }
        if (e.id == 0L) writableDatabase.insert("entries", null, values)
        else writableDatabase.update("entries", values, "id=?", arrayOf(e.id.toString()))
    }
    fun delete(id: Long) { writableDatabase.delete("entries", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private var weekOffset = 0
    private val navy = Color.rgb(23, 45, 80)
    private val gold = Color.rgb(214, 168, 79)
    private val ink = Color.rgb(35, 45, 60)
    private val muted = Color.rgb(105, 115, 130)
    private val money = NumberFormat.getNumberInstance(Locale("id", "ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LedgerDb(this)
        render()
    }

    private fun weekBounds(offset: Int = weekOffset): Pair<String, String> {
        val c = Calendar.getInstance()
        c.firstDayOfWeek = Calendar.MONDAY
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        c.add(Calendar.WEEK_OF_YEAR, offset)
        val start = c.time
        c.add(Calendar.DAY_OF_MONTH, 6)
        return Pair(fmtDate(start), fmtDate(c.time))
    }

    private fun fmtDate(d: Date) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)
    private fun parseDate(s: String): Date = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s) ?: Date()
    private fun displayDate(s: String): String =
        SimpleDateFormat("dd/MM", Locale("id", "ID")).format(parseDate(s))
    private fun dayName(s: String): String =
        SimpleDateFormat("EEEE", Locale("id", "ID")).format(parseDate(s))
            .replaceFirstChar { it.uppercase() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; setOnClickListener { action() }
        }

    private fun render() {
        val (start, end) = weekBounds()
        val entries = db.allBetween(start, end)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 248, 251))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(navy)
        }
        val weeklyPlate = getWeeklyPlate(start)
        header.addView(text("CATATAN MINAN", 20f, Color.WHITE, true))
        header.addView(text(weeklyPlate.ifBlank { "NOMOR PLAT MOBIL: BELUM DIISI" }, 19f, gold, true))
        header.addView(text("MINGGUAN", 27f, gold, true))
        header.addView(text("${displayDate(start)} – ${displayDate(end)}", 13f, Color.WHITE))
        root.addView(header)
        root.addView(button(if (weeklyPlate.isBlank()) "＋ Isi nomor plat minggu ini" else "Ubah nomor plat minggu ini") {
            showWeeklyPlateDialog(start)
        })

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        nav.addView(button("‹ Minggu lalu") { weekOffset--; render() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(button("Minggu depan ›") { weekOffset++; render() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(nav)

        val totalUj = entries.sumOf { it.uj }
        val totalBorongan = entries.sumOf { it.borongan }
        val totalSisa = entries.sumOf { it.sisa }
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(5), 0, dp(10))
        }
        listOf("TOTAL UJ" to totalUj, "BORONGAN" to totalBorongan, "SISA" to totalSisa).forEach { pair ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(9), dp(9), dp(5), dp(9))
                setBackgroundColor(Color.WHITE)
            }
            card.addView(text(pair.first, 10f, muted, true))
            card.addView(text(money.format(pair.second), 17f, navy, true))
            summary.addView(card, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        root.addView(summary)

        root.addView(button("+ Tambah transaksi") { showEntryDialog(null) })

        val horizontal = HorizontalScrollView(this)
        val table = TableLayout(this).apply {
            isStretchAllColumns = false
            setBackgroundColor(Color.WHITE)
        }
        val headerRow = TableRow(this).apply { setBackgroundColor(navy) }
        listOf("TANGGAL", "DARI", "KE", "UJ", "BORONGAN", "SISA", "AKSI").forEach {
            headerRow.addView(cell(it, true))
        }
        table.addView(headerRow)

        val days = (0..6).map { i ->
            val c = Calendar.getInstance()
            c.time = parseDate(start)
            c.add(Calendar.DAY_OF_MONTH, i)
            fmtDate(c.time)
        }
        days.forEach { day ->
            val dayEntries = entries.filter { it.date == day }
            if (dayEntries.isEmpty()) {
                val row = TableRow(this)
                row.addView(cell("${dayName(day)}\n${displayDate(day)}"))
                repeat(6) { row.addView(cell("—")) }
                table.addView(row)
            } else {
                dayEntries.forEachIndexed { index, e ->
                    val row = TableRow(this)
                    row.addView(cell("${if (index == 0) dayName(day) else ""}\n${displayDate(day)}"))
                    row.addView(cell(e.from))
                    row.addView(cell(e.to))
                    row.addView(cell(money.format(e.uj)))
                    row.addView(cell(money.format(e.borongan)))
                    row.addView(cell(money.format(e.sisa)))
                    val actions = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        addView(smallAction("Edit") { showEntryDialog(e) })
                        addView(smallAction("Hapus") {
                            AlertDialog.Builder(this@MainActivity)
                                .setMessage("Hapus transaksi ini?")
                                .setNegativeButton("Batal", null)
                                .setPositiveButton("Hapus") { _, _ -> db.delete(e.id); render() }
                                .show()
                        })
                    }
                    row.addView(actions)
                    table.addView(row)
                }
            }
        }
        val totalRow = TableRow(this).apply { setBackgroundColor(navy) }
        totalRow.addView(cell("TOTAL", true))
        totalRow.addView(cell(""))
        totalRow.addView(cell(""))
        totalRow.addView(cell(money.format(totalUj), true))
        totalRow.addView(cell(money.format(totalBorongan), true))
        totalRow.addView(cell(money.format(totalSisa), true))
        totalRow.addView(cell(""))
        table.addView(totalRow)
        horizontal.addView(table)
        val scroll = ScrollView(this)
        scroll.addView(horizontal)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        root.addView(text("Jumlah transaksi: ${entries.size}", 12f, muted))
        root.addView(button("Bagikan catatan ke WhatsApp") { shareWhatsApp(entries, start, end, weeklyPlate) })
        root.addView(button("Bagikan rekap (CSV)") { shareCsv(entries, start, end) })
        setContentView(root)
    }

    private fun cell(value: String, bold: Boolean = false): TextView =
        text(value, 11f, if (bold) Color.WHITE else ink, bold).apply {
            minWidth = dp(65)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(10), dp(7), dp(10))
            if (!bold) setBackgroundColor(Color.WHITE)
        }

    private fun smallAction(label: String, action: () -> Unit) =
        TextView(this).apply {
            text = label; textSize = 11f; setTextColor(navy)
            setPadding(dp(7), dp(5), dp(7), dp(5))
            setOnClickListener { action() }
        }

    private fun getWeeklyPlate(start: String): String =
        getSharedPreferences("weekly_settings", MODE_PRIVATE).getString("plate_$start", "") ?: ""

    private fun showWeeklyPlateDialog(start: String) {
        val input = EditText(this).apply {
            hint = "Contoh: B 1234 ABC"
            setSingleLine(true)
            setText(getWeeklyPlate(start))
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Nomor plat mobil minggu ini")
            .setView(input)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                getSharedPreferences("weekly_settings", MODE_PRIVATE).edit()
                    .putString("plate_$start", input.text.toString().trim().uppercase(Locale("id", "ID")))
                    .apply()
                render()
            }
            .setNeutralButton("Kosongkan") { _, _ ->
                getSharedPreferences("weekly_settings", MODE_PRIVATE).edit().remove("plate_$start").apply()
                render()
            }
            .show()
    }

    private fun showEntryDialog(existing: Entry?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun field(hint: String, value: String = "", numeric: Boolean = false): EditText {
            val edit = EditText(this)
            edit.hint = hint
            edit.setSingleLine(true)
            if (numeric) edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            edit.setText(value)
            box.addView(edit)
            return edit
        }
        val dateButton = Button(this).apply {
            isAllCaps = false
            text = "Tanggal: ${existing?.date ?: weekBounds().first}"
        }
        var selectedDate = existing?.date ?: weekBounds().first
        dateButton.setOnClickListener {
            val c = Calendar.getInstance()
            c.time = parseDate(selectedDate)
            DatePickerDialog(this, { _, y, m, d ->
                c.set(y, m, d); selectedDate = fmtDate(c.time)
                dateButton.text = "Tanggal: $selectedDate"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        box.addView(dateButton)
        val from = field("Dari", existing?.from ?: "")
        val to = field("Ke", existing?.to ?: "")
        val uj = field("UJ", existing?.uj?.toString() ?: "", true)
        val borongan = field("Borongan", existing?.borongan?.toString() ?: "", true)
        val sisa = field("Sisa", existing?.sisa?.toString() ?: "", true)

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah transaksi" else "Edit transaksi")
            .setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                fun num(v: String) = v.trim().toLongOrNull() ?: 0L
                db.save(Entry(existing?.id ?: 0L, selectedDate,
                    from.text.toString().trim(), to.text.toString().trim(), existing?.plate ?: "",
                    num(uj.text.toString()), num(borongan.text.toString()), num(sisa.text.toString())))
                render()
            }.show()
    }

    private fun shareWhatsApp(entries: List<Entry>, start: String, end: String, weeklyPlate: String) {
        try {
            val imageUri = createWeeklyImage(entries, start, end, weeklyPlate)
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(android.content.Intent.EXTRA_STREAM, imageUri)
                putExtra(android.content.Intent.EXTRA_TEXT, "Rekap Catatan Minan ${weeklyPlate} ${displayDate(start)} – ${displayDate(end)}")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "Bagikan gambar catatan"))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuat gambar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun createWeeklyImage(entries: List<Entry>, start: String, end: String, weeklyPlate: String): Uri {
        val w = 1200
        val margin = 48f
        val titleH = 210f
        val headerH = 76f
        val rowH = 72f
        val totalH = 100f
        val footerH = 60f
        val h = (titleH + headerH + entries.size * rowH + totalH + footerH + 40).toInt()
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        fun rect(color: Int, l: Float, t: Float, r: Float, b: Float) {
            paint.color = color
            canvas.drawRect(l, t, r, b, paint)
        }
        fun label(value: String, x: Float, baseline: Float, size: Float, color: Int, bold: Boolean = false) {
            paint.color = color
            paint.textSize = size
            paint.typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
            canvas.drawText(value, x, baseline, paint)
        }
        rect(Color.rgb(23, 45, 80), 0f, 0f, w.toFloat(), titleH)
        label("CATATAN MINAN", margin, 65f, 42f, Color.WHITE, true)
        label(weeklyPlate.ifBlank { "NOMOR PLAT MOBIL: BELUM DIISI" }, margin, 115f, 32f, Color.rgb(235, 195, 105), true)
        label("Periode: ${displayDate(start)} - ${displayDate(end)}", margin, 170f, 27f, Color.rgb(235, 225, 200))

        val left = margin
        val right = w - margin
        val colW = (right - left) / 6f
        val xs = (0..6).map { left + it * colW }
        val headers = listOf("Tanggal", "Dari", "Ke", "UJ", "Borongan", "Sisa")
        var y = titleH
        rect(Color.rgb(214, 168, 79), 0f, y, w.toFloat(), y + headerH)
        headers.forEachIndexed { i, head -> label(head, xs[i] + 7f, y + 48f, 21f, Color.rgb(30, 38, 50), true) }
        y += headerH
        entries.forEachIndexed { index, e ->
            rect(if (index % 2 == 0) Color.rgb(247, 249, 252) else Color.WHITE, 0f, y, w.toFloat(), y + rowH)
            val values = listOf(
                "${dayName(e.date).take(3)}, ${displayDate(e.date)}",
                e.from.ifBlank { "-" }, e.to.ifBlank { "-" },
                money.format(e.uj), money.format(e.borongan), money.format(e.sisa)
            )
            values.forEachIndexed { i, value ->
                paint.color = ink
                paint.textSize = 22f
                paint.typeface = Typeface.create("sans-serif", if (i >= 3) Typeface.BOLD else Typeface.NORMAL)
                val maxWidth = xs[i + 1] - xs[i] - 14f
                var shown = value
                while (paint.measureText(shown) > maxWidth && shown.length > 4) shown = shown.dropLast(2) + "…"
                canvas.drawText(shown, xs[i] + 10f, y + 45f, paint)
            }
            paint.color = Color.rgb(225, 230, 236)
            paint.strokeWidth = 1f
            canvas.drawLine(margin, y + rowH, w - margin, y + rowH, paint)
            y += rowH
        }
        rect(Color.rgb(235, 241, 248), 0f, y, w.toFloat(), y + totalH)
        label("TOTAL", margin + 10f, y + 38f, 25f, navy, true)
        label("UJ: ${money.format(entries.sumOf { it.uj })}", 190f, y + 38f, 23f, navy, true)
        label("Borongan: ${money.format(entries.sumOf { it.borongan })}", 500f, y + 38f, 23f, navy, true)
        label("Sisa: ${money.format(entries.sumOf { it.sisa })}", 875f, y + 38f, 23f, navy, true)
        label("Jumlah transaksi: ${entries.size}", margin + 10f, y + 76f, 21f, muted)
        val uri: Uri
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Catatan_Mingguan_${start}_$end.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BukuCatatanMingguan")
            }
            uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak dapat menyimpan gambar")
            contentResolver.openOutputStream(uri)?.use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
                ?: throw IllegalStateException("Tidak dapat membuka file gambar")
        } else {
            val file = File(cacheDir, "Catatan_Mingguan_${start}_$end.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        }
        bitmap.recycle()
        return uri
    }

    private fun shareCsv(entries: List<Entry>, start: String, end: String) {
        val csv = buildString {
            append("Tanggal,Dari,Ke,Nomor Plat,UJ,Borongan,Sisa\n")
            entries.forEach {
                append("${it.date},\"${it.from.replace("\"", "\"\"")}\",\"${it.to.replace("\"", "\"\"")}\",\"${it.plate.replace("\"", "\"\"")}\",${it.uj},${it.borongan},${it.sisa}\n")
            }
            append("TOTAL,,,,${entries.sumOf { it.uj }},${entries.sumOf { it.borongan }},${entries.sumOf { it.sisa}}\n")
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Rekap $start sampai $end")
            putExtra(android.content.Intent.EXTRA_TEXT, csv)
        }
        startActivity(android.content.Intent.createChooser(intent, "Bagikan rekap"))
    }
}
