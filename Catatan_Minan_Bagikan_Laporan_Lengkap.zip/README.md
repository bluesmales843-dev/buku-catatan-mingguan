# Catatan Minan

Aplikasi Android pencatatan mingguan dengan database SQLite.

## Fitur
- Catatan transaksi mingguan dan ringkasan total UJ, Borongan, serta Sisa.
- Data rekening driver: nama driver, nama bank, nomor rekening, dan atas nama.
- Tambah, edit, dan hapus transaksi maupun data driver.
- Bagikan laporan mingguan sebagai satu gambar PNG melalui menu berbagi Android (termasuk WhatsApp).
- Gambar laporan berisi tabel transaksi, bagian TOTAL, lalu tabel DATA REKENING DRIVER tepat di bawah TOTAL.

## Build APK
Proyek menggunakan Android Gradle Plugin dan Kotlin. Workflow GitHub Actions tersedia di `.github/workflows/build-apk.yml` untuk membangun APK.
